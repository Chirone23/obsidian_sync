/* ================================================================
   Configuratore Acquisto vs NLT — logica vanilla
   ----------------------------------------------------------------
   COME MODIFICARE I NUMERI:
   - AUTO_DATA  : listino, canone NLT mensile, bollo annuo, svalutazione %
                  manutenzione annua, costo gomme/set, tier per assicurazione
   - CONFIG     : assicurazione base per città, moltiplicatori profilo,
                  TAEG finanziamento, km inclusi NLT, costo km eccedente,
                  durata NLT standard
   - calcBuy()  : formula costo totale acquisto
   - calcNlt()  : formula costo totale noleggio
   ================================================================ */

// Bolli annui: fonte ufficiale ACI/Regione, allineati alle potenze (kW) reali dei modelli.
// Assicurazione: PACCHETTO COMPLETO annuo (RCA + Furto/Incendio + Kasko mini + Cristalli + Soccorso)
//   base BOLOGNA profilo "italiano medio classe 4". Fonte: Prezzi Auto MOC.md
//   (Euroborsa 2026 premio medio nazionale 629 €, Auto.it gen 2026, IVASS preventivatore).
//   Città e profilo si applicano come moltiplicatori in CONFIG.
const AUTO_DATA = [
  {
    id: 'kia-picanto',
    nome: 'KIA Picanto 1.0 GDi Urban',
    prezzo: 15800,
    canone: 346.56,
    bolloAnno: 129,            // 50 kW (era 80, era sottostimato)
    insBologna: 1180,          // pacchetto completo, profilo medio
    svalutazione: 0.40,        // valore residuo % dopo 4 anni (fonte: Eurotax/Quattroruote, range 37-43%, punto medio)
    manuAnno: 320,
    gommeSet: 480,             // un set ogni ~50.000 km
    cittaMult: { bologna: 1.00, milano: 1.12, roma: 1.18 }  // fonte: Prezzi Auto MOC.md — city car
  },
  {
    id: 'fiat-500',
    nome: 'FIAT 500 Hybrid Icon',
    prezzo: 19450,
    canone: 406.29,
    bolloAnno: 129,            // 50 kW
    insBologna: 1280,
    svalutazione: 0.43,        // valore residuo % dopo 4 anni (fonte: Eurotax/Quattroruote, range 40-46%, punto medio)
    manuAnno: 380,
    gommeSet: 520,
    cittaMult: { bologna: 1.00, milano: 1.12, roma: 1.18 }  // fonte: Prezzi Auto MOC.md — city car
  },
  {
    id: 'vw-tcross',
    nome: 'VW T-Cross 1.0 TSI DSG',
    prezzo: 27400,
    canone: 511.69,
    bolloAnno: 219,            // 85 kW (era 168, sottostimato)
    insBologna: 1620,
    svalutazione: 0.47,
    manuAnno: 480,
    gommeSet: 640,
    cittaMult: { bologna: 1.00, milano: 1.10, roma: 1.16 }  // fonte: Prezzi Auto MOC.md — segmento medio
  },
  {
    id: 'nissan-juke',
    nome: 'Nissan Juke 1.6 HEV N-Connecta',
    prezzo: 31700,
    canone: 554.29,
    bolloAnno: 262,            // 105 kW (era 140, fortemente sottostimato)
    insBologna: 1690,
    svalutazione: 0.49,
    manuAnno: 460,
    gommeSet: 620,
    cittaMult: { bologna: 1.00, milano: 1.10, roma: 1.16 }  // fonte: Prezzi Auto MOC.md — segmento medio
  },
  {
    id: 'volvo-xc40',
    nome: 'Volvo XC40 B3 Core',
    prezzo: 43830,
    canone: 778.17,
    bolloAnno: 308,            // 120 kW (era 252)
    insBologna: 2420,
    svalutazione: 0.52,
    manuAnno: 620,
    gommeSet: 780,
    cittaMult: { bologna: 1.00, milano: 1.10, roma: 1.16 }  // fonte: Prezzi Auto MOC.md — segmento medio/alto
  }
];

const CONFIG = {
  // Moltiplicatori profilo guidatore.
  // "medio" = italiano medio classe 4 (default, ancorato a premio medio 629 € Euroborsa).
  // "giovane" e "neopatentato" sovrapprezzi standard di mercato.
  insMultProfilo: {
    medio:        1.0,   // 42 anni, classe 4, 1 sinistro storico fuori osservazione
    giovane:      1.28,  // under 30 — fonte MOC: +20/+35% pacchetto, punto medio
    neopatentato: 1.7    // neopatentato in famiglia come 2° guidatore
  },
  // Costo immatricolazione per città (auto nuova, comprende costi fissi ACI/Motorizzazione
  // ~145 €: emolumenti ACI 27€ + diritti DTT 10,20€ + bollo PRA 32€ + targa ~41,78€ + IVA varie)
  // + IPT (Imposta Provinciale di Trascrizione): base 150,81€ per auto ≤53 kW, poi 3,5119€/kW extra.
  // Le province possono maggiorare l'IPT fino al +30%. Bologna: nessuna maggiorazione (290 €);
  // Milano: +20% IPT (305 €); Roma: +15% IPT (298 €). Fonte: ACI / Quattroruote 2025.
  // Nel configuratore l'immatricolazione è inclusa nel canone NLT (voce "immatricolazione" già compresa).
  immatricolazioneCitta: {
    bologna: 290,   // fissi ~145 + IPT 150,81 (no maggiorazione)
    milano:  305,   // fissi ~145 + IPT 150,81 +20% ≈ 181
    roma:    298    // fissi ~145 + IPT 150,81 +15% ≈ 173
  },
  taeg:        0.1199,           // 11,99%
  finMesi:     36,               // durata standard finanziamento
  finAnticipoPct: 0,             // anticipo finanziamento (0 = nessuno)
  nltKmInclusi: 120000,          // km inclusi nel contratto NLT standard
  nltDurataMesi: 48,             // durata NLT standard
  nltCostoKmExtra: 0.10,         // €/km eccedente
  gommeKmCiclo:   50000,         // km per set di pneumatici
  deltaEquivsoglia: 200,         // € sotto cui i due costi sono "sostanzialmente equivalenti"
  iva: 1.22,                     // aliquota IVA auto nuove Italia
  kmOptions:    [5000, 10000, 15000, 20000, 30000],
  anniOptions:  [3, 4, 5, 6, 8],
  kmDefaultIdx:  2,
  anniDefaultIdx:1
};

/* ---------- STATO ---------- */
const state = {
  carId: 'fiat-500',
  km: CONFIG.kmOptions[CONFIG.kmDefaultIdx],
  anni: CONFIG.anniOptions[CONFIG.anniDefaultIdx],
  citta: 'bologna',
  modalita: 'finanziato', // unica modalità supportata
  profilo: 'medio'
};

/* ---------- HELPERS ---------- */
const fmt = (n) => {
  const v = Math.round(n);
  return new Intl.NumberFormat('it-IT').format(v) + ' €';
};
const fmtMese = (n) => new Intl.NumberFormat('it-IT', {minimumFractionDigits: 2, maximumFractionDigits: 2}).format(n) + ' €';
const car = () => AUTO_DATA.find(c => c.id === state.carId);
const cap = (s) => s ? s.charAt(0).toUpperCase() + s.slice(1) : s;

/* ---------- CALCOLO ACQUISTO ----------
   Costo netto = prezzo + interessi (se finanziato) + assicurazione + bollo
                 + manutenzione + gomme − valore residuo
   Svalutazione: il residuo dopo X anni è prezzo * (svalutazione_4y)^(X/4)
   approssimazione esponenziale (auto perde valore in modo non lineare).
---------------------------------------- */
function calcBuy() {
  const c = car();
  const anni = state.anni;
  const kmTot = state.km * anni;

  // 1. interessi finanziamento (approssimazione amortizing su finMesi)
  let interessi = 0;
  if (state.modalita === 'finanziato') {
    // formula semplice: P * TAEG * (finMesi/12) / 2 → media sul capitale residuo
    interessi = c.prezzo * CONFIG.taeg * (CONFIG.finMesi / 12) / 2;
  }

  // 2. assicurazione: premio specifico per auto (base Bologna profilo medio)
  //    × moltiplicatore città × moltiplicatore profilo guidatore.
  const insAnno = c.insBologna
                * c.cittaMult[state.citta]
                * CONFIG.insMultProfilo[state.profilo];
  const assicurazione = insAnno * anni;

  // 3. bollo
  const bollo = c.bolloAnno * anni;

  // 4. manutenzione + gomme
  const manutenzione = c.manuAnno * anni;
  const setGomme = Math.max(1, Math.floor(kmTot / CONFIG.gommeKmCiclo));
  const gomme = c.gommeSet * setGomme;

  // 5. immatricolazione (costi fissi ACI/Motorizzazione + IPT per provincia)
  const immatricolazione = CONFIG.immatricolazioneCitta[state.citta];

  // 6. valore residuo: base ex-IVA (22%) × curva di svalutazione
  //    Il privato vende/permuta al prezzo di mercato usato, che esclude IVA
  //    → la base di partenza è prezzo/1.22, non il listino IVA inclusa
  const residuoPct = Math.pow(c.svalutazione, anni / 4);
  const residuo = (c.prezzo / CONFIG.iva) * residuoPct;

  // Esborso reale = tutto ciò che esce dal conto corrente nei mesi
  const esborsoLordo = c.prezzo + interessi + assicurazione + bollo + manutenzione + gomme + immatricolazione;
  // Costo netto economico = esborso − valore recuperato dalla rivendita
  const totale = esborsoLordo - residuo;

  return {
    voci: [
      { label: 'Prezzo auto',                    val: c.prezzo,
        tip: 'Il prezzo di listino IVA inclusa che paghi al concessionario.' },
      ...(state.modalita === 'finanziato'
        ? [{ label: `Interessi finanziamento (TAEG ${(CONFIG.taeg*100).toFixed(2).replace('.',',')}%)`, val: interessi,
             tip: `Con un TAEG dell'${(CONFIG.taeg*100).toFixed(2).replace('.',',')}% su ${CONFIG.finMesi} mesi, la banca ti addebita questi interessi in aggiunta al capitale. È il costo del "pagare a rate".` }]
        : []),
      { label: `Immatricolazione (${cap(state.citta)})`,          val: immatricolazione,
        tip: `Costi fissi ACI + Motorizzazione (~145 €) + Imposta Provinciale di Trascrizione (IPT) variabile per provincia. Si paga una volta sola all'acquisto.` },
      { label: `Assicurazione (${cap(state.citta)}, ${anni} ${anni===1?'anno':'anni'})`, val: assicurazione,
        tip: 'Include RCA obbligatoria + Furto & Incendio + Kasko base. Il premio varia per città, profilo guidatore e tipo di auto. Stima indicativa: tariffe reali possono differire.' },
      { label: `Bollo (${anni} ${anni===1?'anno':'anni'})`,           val: bollo,
        tip: 'Tassa automobilistica annuale calcolata sulla potenza del motore (kW). Obbligatoria anche se non usi l\'auto.' },
      { label: `Manutenzione ordinaria (${anni} ${anni===1?'anno':'anni'})`,    val: manutenzione,
        tip: 'Tagliandi, filtri, freni, liquidi. Non include riparazioni straordinarie impreviste — quelle sono a carico tuo e non compaiono qui.' },
      { label: `Pneumatici (${setGomme} cambio${setGomme > 1 ? ' stimati' : ''})`, val: gomme,
        tip: `Un treno di pneumatici ogni ~50.000 km. Stima media di mercato per questa categoria di auto. I prezzi effettivi variano per marca e modello di gomma.` },
      { label: 'Totale uscite dal conto',               val: esborsoLordo, sub: true,
        tip: 'Somma di tutto quello che paghi concretamente: auto + rate + assicurazioni + tasse + manutenzione. Soldi che escono dal tuo conto in 4 anni.' },
      { label: `Rivendita stimata (${(residuoPct*100).toFixed(0)}% del valore ex-IVA)`, val: -residuo, neg: true,
        tip: `Stima del prezzo di mercato se rivendi l'auto a fine periodo. Calcolata sul valore ex-IVA (il mercato usato non include l'IVA del listino nuovo). È una stima: il valore reale dipende da chilometri, stato e domanda al momento della vendita.` },
      { label: 'Costo netto dopo rivendita',     val: totale, tot: true,
        tip: 'Uscite totali meno il ricavo stimato dalla rivendita. È il costo economico finale — ma presuppone che tu venda davvero l\'auto al prezzo stimato.' }
    ],
    totale,
    esborsoLordo,
    residuo,
    residuoPct
  };
}

/* ---------- CALCOLO NOLEGGIO ----------
   - Canone × mesi (limitato a durata contratto standard 48m;
     se l'utente sceglie >4 anni, simuliamo rinnovo allo stesso canone
     — onesto: in realtà il canone alla rinnovo cambia leggermente)
   - Km eccedenti calcolati sulla durata totale rapportata ai km inclusi
---------------------------------------- */
function calcNlt() {
  const c = car();
  const anni = state.anni;
  const mesi = anni * 12;
  const kmTot = state.km * anni;

  // km inclusi proporzionati alla durata effettiva
  const kmInclusiTot = (CONFIG.nltKmInclusi / CONFIG.nltDurataMesi) * mesi;
  const kmExtra = Math.max(0, kmTot - kmInclusiTot);
  const costoKmExtra = kmExtra * CONFIG.nltCostoKmExtra;

  const canoneTot = c.canone * mesi;
  const anticipo = 0;
  const totale = canoneTot + costoKmExtra + anticipo;

  return {
    canone: c.canone,
    mesi,
    voci: [
      { label: `Canone mensile × ${mesi} mesi`,  val: canoneTot,
        tip: 'Il canone include tutto: auto, assicurazione completa, manutenzione ordinaria e straordinaria, pneumatici, bollo, immatricolazione, soccorso stradale e gestione sinistri. Nessun extra nascosto.' },
      { label: 'Anticipo',                        val: anticipo, hl: true,
        tip: 'Con questo contratto non si paga alcun anticipo iniziale. Il primo canone copre già tutto dal primo giorno.' },
      ...(kmExtra > 0
        ? [{ label: `Km eccedenti (${Math.round(kmExtra).toLocaleString('it-IT')} km extra)`, val: costoKmExtra,
             tip: `Hai inserito più km di quelli inclusi nel contratto (${Math.round(kmInclusiTot).toLocaleString('it-IT')} km). I km extra si pagano a fine contratto a 0,10 €/km. Riduci i km annui per azzerare questo costo.` }]
        : [{ label: `Km inclusi (${Math.round(kmInclusiTot).toLocaleString('it-IT')} km — nessun extra)`, val: 0, hl: true,
             tip: 'I tuoi km annui rientrano nel contratto standard. A fine noleggio non paghi nulla per i chilometri percorsi.' }]
      ),
      { label: 'Costo totale noleggio',           val: totale, tot: true,
        tip: 'La cifra che paghi in totale per avere l\'auto, completamente assicurata e mantenuta, per tutta la durata del contratto. Niente sorprese.' }
    ],
    totale
  };
}

/* ---------- COUNT-UP ANIMAZIONE ---------- */
function animateNumber(el, target, formatter, duration = 500) {
  if (!Number.isFinite(target)) { el.textContent = '—'; return; }
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    el.textContent = formatter(target);
    el.dataset.val = String(target);
    return;
  }
  // se è il primo render (dataset.val non impostato) → set diretto, niente animazione
  if (el.dataset.val === undefined || el.dataset.val === '') {
    el.textContent = formatter(target);
    el.dataset.val = String(target);
    return;
  }
  // cancella eventuale rAF precedente per evitare race fra animazioni sovrapposte
  if (el._raf) cancelAnimationFrame(el._raf);
  const start = parseFloat(el.dataset.val);
  if (!Number.isFinite(start) || Math.abs(target - start) < 0.005) {
    el.textContent = formatter(target);
    el.dataset.val = String(target);
    return;
  }
  const t0 = performance.now();
  function step(now) {
    const p = Math.min(1, (now - t0) / duration);
    const eased = 1 - Math.pow(1 - p, 3);
    const v = start + (target - start) * eased;
    el.textContent = formatter(v);
    if (p < 1) el._raf = requestAnimationFrame(step);
    else { el.dataset.val = String(target); el._raf = null; }
  }
  el._raf = requestAnimationFrame(step);
}

/* ---------- RENDER ---------- */
function renderCars() {
  const grid = document.getElementById('carGrid');
  grid.innerHTML = AUTO_DATA.map(c => `
    <button type="button" class="car" role="radio"
            aria-checked="${c.id === state.carId}"
            data-id="${c.id}">
      <div class="car-thumb" aria-hidden="true">
        <img src="img/auto/${c.id}.png" alt="${c.nome}"
             onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
        <span class="car-thumb-fallback">${c.nome.split(' ')[0].toUpperCase()}</span>
      </div>
      <div class="car-name">${c.nome}</div>
      <div class="car-meta">
        <span>Listino</span><strong>${fmt(c.prezzo)}</strong>
      </div>
      <div class="car-meta">
        <span>NLT 48m</span><strong>${fmtMese(c.canone)}/mese</strong>
      </div>
    </button>
  `).join('');

  grid.querySelectorAll('.car').forEach(btn => {
    btn.addEventListener('click', () => {
      state.carId = btn.dataset.id;
      grid.querySelectorAll('.car').forEach(b => b.setAttribute('aria-checked', b.dataset.id === state.carId));
      const leadSel = document.getElementById('leadAuto');
      if (leadSel) leadSel.value = state.carId;
      render();
    });
  });

  // popola select del form
  const leadSel = document.getElementById('leadAuto');
  leadSel.innerHTML = AUTO_DATA.map(c => `<option value="${c.id}">${c.nome}</option>`).join('');
  leadSel.value = state.carId;
}

function renderBreakdown(ulId, voci, fmtFn) {
  const ul = document.getElementById(ulId);
  ul.innerHTML = voci.map(v => {
    const cls = [v.neg && 'neg', v.hl && 'hl', v.tot && 'tot', v.sub && 'sub'].filter(Boolean).join(' ');
    const valTxt = v.val === 0 && v.hl ? '0 €' : fmtFn(v.val);
    const tipBtn = v.tip
      ? `<button type="button" class="info-btn bk-info" aria-label="Informazioni" data-tip="${v.tip.replace(/"/g, '&quot;')}">ⓘ</button>`
      : '';
    return `<li class="${cls}"><span class="bk-label-wrap">${tipBtn}${v.label}</span><span>${valTxt}</span></li>`;
  }).join('');

  // attiva tooltip per i bottoni appena creati
  ul.querySelectorAll('.bk-info').forEach(btn => {
    let tip = btn._tipEl;
    const show = () => {
      if (!tip) {
        tip = document.createElement('span');
        tip.className = 'info-tip';
        tip.textContent = btn.dataset.tip;
        btn.appendChild(tip);
        btn._tipEl = tip;
      }
      tip.classList.add('visible');
    };
    const hide = () => tip && tip.classList.remove('visible');
    btn.addEventListener('mouseenter', show);
    btn.addEventListener('mouseleave', hide);
    btn.addEventListener('focus', show);
    btn.addEventListener('blur', hide);
    btn.addEventListener('click', e => {
      e.stopPropagation();
      tip && tip.classList.contains('visible') ? hide() : show();
    });
  });
}

function renderDelta(buyTot, nltTot) {
  const box = document.getElementById('delta');
  const fill = document.getElementById('deltaFill');
  const msg = document.getElementById('deltaMsg');
  const diff = buyTot - nltTot;       // positivo = NLT conviene
  const ref = Math.max(buyTot, nltTot);
  const pct = Math.min(100, Math.abs(diff) / ref * 100);
  fill.style.width = pct.toFixed(1) + '%';

  if (Math.abs(diff) < CONFIG.deltaEquivsoglia) {
    msg.innerHTML = `Costi sostanzialmente <strong>equivalenti</strong> sull'orizzonte selezionato. Sul noleggio però non hai pensieri operativi.`;
    box.classList.remove('flip');
  } else if (diff > 0) {
    msg.innerHTML = `Con il noleggio risparmi <strong>${fmt(diff)}</strong> e includi tutto: manutenzione, assicurazione, gomme, sinistri.`;
    box.classList.remove('flip');
  } else {
    msg.innerHTML = `Sull'orizzonte scelto l'acquisto costa <strong>${fmt(Math.abs(diff))}</strong> in meno. Valuta però imprevisti, immobilizzo e rivendita.`;
    box.classList.add('flip');
  }
}

function renderChart(buy, nlt) {
  const svg = document.getElementById('chart');
  const W = 800, H = 320, P = 36;
  const mesi = state.anni * 12;

  // Punti acquisto: simuliamo eventi mensili
  const c = car();
  const buyPts = [];
  let cum = 0;
  // anticipo "0" → primo punto al mese 0 = 0
  buyPts.push({ m: 0, v: 0 });

  if (state.modalita === 'finanziato') {
    const rateMesi = Math.min(CONFIG.finMesi, mesi);
    const rataCap = c.prezzo / rateMesi;
    const interessiTot = c.prezzo * CONFIG.taeg * (CONFIG.finMesi / 12) / 2;
    const rataInt = interessiTot / rateMesi;
    for (let m = 1; m <= mesi; m++) {
      if (m <= rateMesi) cum += rataCap + rataInt;
      // assicurazione + bollo + manutenzione spalmati mensilmente
      cum += (c.insBologna * c.cittaMult[state.citta] * CONFIG.insMultProfilo[state.profilo]) / 12;
      cum += c.bolloAnno / 12;
      cum += c.manuAnno / 12;
      // gomme: scatto ogni 50.000 km
      const kmAlMese = state.km / 12;
      if (m % Math.max(1, Math.round(CONFIG.gommeKmCiclo / state.km * 12)) === 0) cum += c.gommeSet;
      buyPts.push({ m, v: cum });
    }
  } else {
    // contanti: scatto iniziale grande
    cum = c.prezzo;
    buyPts.push({ m: 0.01, v: cum });
    for (let m = 1; m <= mesi; m++) {
      cum += (c.insBologna * c.cittaMult[state.citta] * CONFIG.insMultProfilo[state.profilo]) / 12;
      cum += c.bolloAnno / 12;
      cum += c.manuAnno / 12;
      if (m % Math.max(1, Math.round(CONFIG.gommeKmCiclo / state.km * 12)) === 0) cum += c.gommeSet;
      buyPts.push({ m, v: cum });
    }
  }
  // Nota: NON sottraiamo il residuo dalla curva — la linea mostra
  // l'esborso reale cumulato. Il residuo è disegnato a parte come
  // segmento tratteggiato verticale a fine periodo (vedi sotto).
  const residuoPct = Math.pow(c.svalutazione, state.anni / 4);
  const residuoVal = (c.prezzo / CONFIG.iva) * residuoPct;
  const esborsoFinale = buyPts[buyPts.length - 1].v;
  const nettoFinale = esborsoFinale - residuoVal;

  // Punti NLT: lineari
  const nltPts = [{ m: 0, v: 0 }, { m: mesi, v: nlt.totale }];
  // aggiungiamo punti intermedi per la linea spezzata visiva
  const nltLin = [];
  for (let m = 0; m <= mesi; m += Math.max(1, Math.round(mesi / 12))) {
    nltLin.push({ m, v: (nlt.totale / mesi) * m });
  }
  nltLin.push({ m: mesi, v: nlt.totale });

  const maxV = Math.max(buyPts[buyPts.length-1].v, nlt.totale, ...buyPts.map(p=>p.v)) * 1.1;
  const sx = m => P + (W - 2*P) * (m / mesi);
  const sy = v => H - P - (H - 2*P) * (v / maxV);

  const pathBuy = buyPts.map((p,i) => (i ? 'L' : 'M') + sx(p.m).toFixed(1) + ',' + sy(p.v).toFixed(1)).join(' ');
  const pathNlt = nltLin.map((p,i) => (i ? 'L' : 'M') + sx(p.m).toFixed(1) + ',' + sy(p.v).toFixed(1)).join(' ');

  // gridlines anni
  let grid = '';
  for (let a = 0; a <= state.anni; a++) {
    const x = sx(a*12);
    grid += `<line x1="${x}" x2="${x}" y1="${P}" y2="${H-P}" stroke="currentColor" stroke-opacity=".08" stroke-dasharray="2 4"/>`;
    grid += `<text x="${x}" y="${H-12}" text-anchor="middle" font-size="11" fill="currentColor" opacity=".5">${a} anni</text>`;
  }

  const buyColor = getComputedStyle(document.documentElement).getPropertyValue('--buy').trim();
  const nltColor = getComputedStyle(document.documentElement).getPropertyValue('--nlt').trim();

  // Marker rivendita: segmento tratteggiato dal punto esborso finale
  // giù fino al "costo netto economico" (= dopo aver recuperato il residuo)
  const xEnd = sx(mesi).toFixed(1);
  const yEsborso = sy(esborsoFinale).toFixed(1);
  const yNetto = sy(nettoFinale).toFixed(1);

  svg.innerHTML = `
    ${grid}
    <path d="${pathBuy}" fill="none" stroke="${buyColor}" stroke-width="2.5" stroke-linejoin="round"/>
    <path d="${pathNlt}" fill="none" stroke="${nltColor}" stroke-width="2.5" stroke-linejoin="round"/>
    <line x1="${xEnd}" x2="${xEnd}" y1="${yEsborso}" y2="${yNetto}"
          stroke="${buyColor}" stroke-width="1.5" stroke-dasharray="4 3" opacity="0.7"/>
    <circle cx="${xEnd}" cy="${yEsborso}" r="5" fill="${buyColor}"/>
    <circle cx="${xEnd}" cy="${yNetto}" r="4" fill="none" stroke="${buyColor}" stroke-width="1.5"/>
    <circle cx="${xEnd}" cy="${sy(nlt.totale).toFixed(1)}" r="5" fill="${nltColor}"/>
  `;
}

function render() {
  const b = calcBuy();
  const n = calcNlt();

  // big numbers
  animateNumber(document.getElementById('buyEsborso'), b.esborsoLordo, (v)=>fmt(v));
  animateNumber(document.getElementById('buyResiduo'), b.residuo, (v)=>fmt(v));
  animateNumber(document.getElementById('buyNetto'),   b.totale,      (v)=>fmt(v));
  animateNumber(document.getElementById('nltCanone'),  n.canone,      (v)=>fmtMese(v));
  animateNumber(document.getElementById('nltTotal'),   n.totale,      (v)=>fmt(v));

  // periodi
  document.getElementById('buyPeriod').textContent = `in ${state.anni} ${state.anni === 1 ? 'anno' : 'anni'}`;
  document.getElementById('nltPeriod').textContent = `× ${n.mesi} mesi`;

  // tooltip residuo dinamico
  const tipResiduo = document.getElementById('tip-buy-residuo');
  if (tipResiduo) {
    tipResiduo.textContent = `Stima del prezzo di mercato dell'auto dopo ${state.anni} ${state.anni === 1 ? 'anno' : 'anni'}, basata su svalutazione media a 4 anni (${(b.residuoPct * 100).toFixed(0)}% del valore ex-IVA). Fonte: Eurotax/Quattroruote. Non è garantita: dipende dalle condizioni dell'auto, dal mercato dell'usato e da quando scegli di vendere.`;
  }

  // breakdown
  renderBreakdown('buyList', b.voci, fmt);
  renderBreakdown('nltList', n.voci, fmt);

  // delta + chart
  renderDelta(b.esborsoLordo, n.totale);
  renderChart(b, n);
}

/* ---------- BINDING UI ---------- */
function bind() {
  const km = document.getElementById('km');
  const kmOut = document.getElementById('kmOut');
  const anni = document.getElementById('anni');
  const anniOut = document.getElementById('anniOut');

  km.addEventListener('input', () => {
    state.km = CONFIG.kmOptions[+km.value];
    kmOut.textContent = state.km.toLocaleString('it-IT') + ' km';
    km.setAttribute('aria-valuenow', state.km);
    km.setAttribute('aria-valuetext', state.km.toLocaleString('it-IT') + ' km');
    render();
  });
  anni.addEventListener('input', () => {
    state.anni = CONFIG.anniOptions[+anni.value];
    anniOut.textContent = state.anni + ' anni';
    anni.setAttribute('aria-valuenow', state.anni);
    anni.setAttribute('aria-valuetext', state.anni + ' anni');
    render();
  });

  document.getElementById('citta').addEventListener('change', e => { state.citta = e.target.value; render(); });
  document.getElementById('profilo').addEventListener('change', e => { state.profilo = e.target.value; render(); });

  // init slider labels + aria
  kmOut.textContent = state.km.toLocaleString('it-IT') + ' km';
  anniOut.textContent = state.anni + ' anni';
  km.setAttribute('aria-valuenow', state.km);
  km.setAttribute('aria-valuetext', state.km.toLocaleString('it-IT') + ' km');
  anni.setAttribute('aria-valuenow', state.anni);
  anni.setAttribute('aria-valuetext', state.anni + ' anni');

  // theme
  const tt = document.getElementById('themeToggle');
  let saved = null;
  try { saved = localStorage.getItem('theme'); } catch (_) {}
  if (saved) document.documentElement.setAttribute('data-theme', saved);
  else if (window.matchMedia('(prefers-color-scheme: dark)').matches) document.documentElement.setAttribute('data-theme', 'dark');
  tt.addEventListener('click', () => {
    const cur = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', cur);
    try { localStorage.setItem('theme', cur); } catch (_) {}
    render(); // ridipinge chart con nuovi colori
  });

  // Info tooltips — hover su desktop, click su mobile
  function closeAllTips() {
    document.querySelectorAll('.info-tip.visible').forEach(t => t.classList.remove('visible'));
  }
  document.querySelectorAll('.info-btn').forEach(btn => {
    const tipId = 'tip-' + btn.dataset.tip;
    const tip = document.getElementById(tipId);
    if (!tip) return;
    // hover (desktop)
    btn.addEventListener('mouseenter', () => { closeAllTips(); tip.classList.add('visible'); });
    btn.addEventListener('mouseleave', () => tip.classList.remove('visible'));
    // click (mobile e tastiera)
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const isOpen = tip.classList.contains('visible');
      closeAllTips();
      if (!isOpen) tip.classList.add('visible');
    });
  });
  document.addEventListener('click', closeAllTips);

  // form
  const form = document.getElementById('leadForm');
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    if (!form.checkValidity()) { form.reportValidity(); return; }
    document.getElementById('formOk').hidden = false;
    form.reset();
    document.getElementById('leadAuto').value = state.carId;
  });
}

/* ---------- BOOT ---------- */
function showError(err) {
  let box = document.getElementById('__errBox');
  if (!box) {
    box = document.createElement('div');
    box.id = '__errBox';
    box.style.cssText = 'position:fixed;left:12px;right:12px;bottom:12px;z-index:9999;background:#fee;border:1px solid #c33;color:#a00;padding:10px 14px;border-radius:8px;font:13px/1.4 system-ui;white-space:pre-wrap;max-height:40vh;overflow:auto;';
    document.body.appendChild(box);
  }
  box.textContent = 'JS error: ' + (err && err.stack || err);
  console.error(err);
}
window.addEventListener('error', (e) => showError(e.error || e.message));
window.addEventListener('unhandledrejection', (e) => showError(e.reason));

function boot() {
  try {
    renderCars();
    bind();
    render();
  } catch (err) { showError(err); }
}

// con script defer DOMContentLoaded può essere già scattato → fallback diretto
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', boot);
} else {
  boot();
}

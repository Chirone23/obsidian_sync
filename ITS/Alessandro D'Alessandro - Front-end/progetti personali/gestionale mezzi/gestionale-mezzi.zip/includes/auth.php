<?php

add_filter( 'auth_cookie_expiration', 'gm_auth_cookie_expiration', 10, 2 );

function gm_auth_cookie_expiration( $expiration, $user_id ) {
    $user = get_userdata( $user_id );
    $gm_roles = [ 'gm_volontario', 'gm_direttivo', 'gm_amministrazione' ];

    if ( ! empty( array_intersect( $gm_roles, (array) $user->roles ) ) ) {
        return WEEK_IN_SECONDS;
    }

    return $expiration;
}

function gm_current_user_can_role( $role ) {
    $user = wp_get_current_user();
    return in_array( $role, (array) $user->roles, true );
}

function gm_redirect_if_not_logged_in() {
    if ( ! is_user_logged_in() ) {
        wp_safe_redirect( wp_login_url( remove_query_arg( 'loggedout' ) ) );
        exit;
    }
}

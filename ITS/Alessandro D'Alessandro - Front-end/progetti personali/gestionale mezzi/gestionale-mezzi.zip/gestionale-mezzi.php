<?php
/**
 * Plugin Name: Gestionale Mezzi
 * Plugin URI: https://gestionale-mezzi.example.com
 * Description: Gestionale veicoli per ente protezione civile
 * Version: 1.0
 * Author: Chirone
 * Text Domain: gestionale-mezzi
 * Domain Path: /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'GESTIONALE_MEZZI_PATH', plugin_dir_path( __FILE__ ) );
define( 'GESTIONALE_MEZZI_URL', plugin_dir_url( __FILE__ ) );
define( 'GESTIONALE_MEZZI_VERSION', '1.0' );

require_once GESTIONALE_MEZZI_PATH . 'includes/db-setup.php';
require_once GESTIONALE_MEZZI_PATH . 'includes/roles.php';
require_once GESTIONALE_MEZZI_PATH . 'includes/auth.php';

register_activation_hook( __FILE__, 'gm_activate_plugin' );
register_deactivation_hook( __FILE__, 'gm_deactivate_plugin' );

function gm_activate_plugin() {
    gm_create_tables();
    gm_register_roles();
    flush_rewrite_rules();
}

function gm_deactivate_plugin() {
    gm_remove_roles();
}

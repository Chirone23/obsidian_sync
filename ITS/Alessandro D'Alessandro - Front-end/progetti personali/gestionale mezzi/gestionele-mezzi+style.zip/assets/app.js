/**
 * GESTIONALE MEZZI - JavaScript (Bootstrap 5)
 * Bootstrap gestisce Offcanvas automaticamente
 */

(function() {
    'use strict';

    // DOM Ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    function init() {
        // Bootstrap Offcanvas è già gestito automaticamente via data-bs-toggle
        // Aggiungi qui logica custom se necessario

        // Auto-close sidebar su mobile quando clicco su un link
        const sidebar = document.getElementById('gm-sidebar');
        if (sidebar) {
            const sidebarLinks = sidebar.querySelectorAll('.nav-link');
            const bsOffcanvas = bootstrap.Offcanvas.getInstance(sidebar) || new bootstrap.Offcanvas(sidebar);

            sidebarLinks.forEach(function(link) {
                link.addEventListener('click', function() {
                    // Chiudi solo su mobile/tablet
                    if (window.innerWidth < 1024) {
                        bsOffcanvas.hide();
                    }
                });
            });
        }

        // Log per debug (rimuovi in produzione)
        console.log('Gestionale Mezzi initialized with Bootstrap 5');
    }

})();

<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$user = wp_get_current_user();
$user_display_name = $user->display_name;

$menu_items = gm_get_menu_items();
?>

<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <?php wp_head(); ?>
</head>
<body class="gm-body bg-light">

<!-- Header -->
<nav class="navbar navbar-expand-lg navbar-light bg-white border-bottom shadow-sm fixed-top">
    <div class="container-fluid">
        <button class="btn btn-link text-dark p-0 me-3" type="button" data-bs-toggle="offcanvas" data-bs-target="#gm-sidebar" aria-controls="gm-sidebar" aria-label="Menu">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="3" y1="6" x2="21" y2="6"></line>
                <line x1="3" y1="12" x2="21" y2="12"></line>
                <line x1="3" y1="18" x2="21" y2="18"></line>
            </svg>
        </button>

        <a class="navbar-brand fw-bold text-primary mb-0" href="<?php echo esc_url( home_url( '/gestionale-dashboard/' ) ); ?>">
            Gestionale Mezzi
        </a>

        <div class="d-flex align-items-center gap-2">
            <span class="d-none d-md-inline text-muted small"><?php echo esc_html( $user_display_name ); ?></span>
            <a href="<?php echo esc_url( wp_logout_url( home_url() ) ); ?>" class="btn btn-sm btn-outline-secondary">Esci</a>
        </div>
    </div>
</nav>

<!-- Sidebar Offcanvas -->
<div class="offcanvas offcanvas-start" tabindex="-1" id="gm-sidebar" aria-labelledby="gm-sidebar-label">
    <div class="offcanvas-header border-bottom">
        <h5 class="offcanvas-title text-primary fw-bold" id="gm-sidebar-label">Menu</h5>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Chiudi"></button>
    </div>
    <div class="offcanvas-body p-0">
        <nav class="nav flex-column">
            <?php foreach ( $menu_items as $item ) : ?>
                <a href="<?php echo esc_url( $item['url'] ); ?>" class="nav-link text-dark py-3 px-4 border-bottom">
                    <?php echo esc_html( $item['label'] ); ?>
                </a>
            <?php endforeach; ?>
        </nav>
    </div>
</div>

<!-- Main Content -->
<main class="container-fluid py-4" style="margin-top: 70px;">
    <?php
    // Contenuto dinamico caricato dai template
    if ( isset( $content ) ) {
        echo $content;
    }
    ?>
</main>

<!-- Bootstrap 5 JS Bundle (include Popper) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<?php wp_footer(); ?>
</body>
</html>

<?php
function gm_get_menu_items() {
    $user = wp_get_current_user();
    $items = [];

    // Dashboard - tutti
    $items[] = [
        'label' => 'Dashboard',
        'url' => home_url( '/gestionale-dashboard/' )
    ];

    // Nuovo Foglio - tutti con capability
    if ( current_user_can( 'gm_create_foglio' ) ) {
        $items[] = [
            'label' => 'Nuovo Foglio',
            'url' => home_url( '/gestionale-nuovo-foglio/' )
        ];
    }

    // I Miei Fogli - tutti
    $items[] = [
        'label' => 'I Miei Fogli',
        'url' => home_url( '/gestionale-i-miei-fogli/' )
    ];

    // Tutti i Fogli - solo direttivo/amministrazione
    if ( current_user_can( 'gm_read_all' ) ) {
        $items[] = [
            'label' => 'Tutti i Fogli',
            'url' => home_url( '/gestionale-tutti-i-fogli/' )
        ];
    }

    // Gestione Utenti - solo direttivo/amministrazione
    if ( current_user_can( 'gm_manage_users' ) ) {
        $items[] = [
            'label' => 'Gestione Utenti',
            'url' => home_url( '/gestionale-gestione-utenti/' )
        ];
    }

    // Gestione Veicoli - solo direttivo/amministrazione
    if ( current_user_can( 'gm_manage_veicoli' ) ) {
        $items[] = [
            'label' => 'Gestione Veicoli',
            'url' => home_url( '/gestionale-gestione-veicoli/' )
        ];
    }

    // Log Attività - solo amministrazione
    if ( current_user_can( 'gm_view_log' ) ) {
        $items[] = [
            'label' => 'Log Attività',
            'url' => home_url( '/gestionale-log-attivita/' )
        ];
    }

    return $items;
}
?>

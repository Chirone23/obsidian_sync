<?php
get_header();
?>

<section class="hero-section">

    <div class="container">

        <h1>La tua libreria online</h1>

        <p>
            Scopri migliaia di libri accuratamente selezionati.
            Romanzi, saggi, fantasy, thriller e molto altro.
        </p>

        <a href="/shop" class="hero-button">
            Esplora il catalogo
        </a>

    </div>

</section>

<section class="container products-home">

    <h2>Ultimi Arrivi</h2>

    <?php

    echo do_shortcode('[products limit="8" columns="4" orderby="date"]');

    ?>

</section>

<?php
get_footer();
?>
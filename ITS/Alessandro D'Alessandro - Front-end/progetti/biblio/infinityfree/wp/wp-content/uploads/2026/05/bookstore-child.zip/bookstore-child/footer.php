<footer class="site-footer">

   	<p>
        © <?php echo date('Y'); ?> La tua libreria online
    </p>

</footer>

<?php wp_footer(); ?>

</body>
</html>
<?php

function bookstore_child_enqueue_styles() {

    wp_enqueue_style(
        'parent-style',
        get_template_directory_uri() . '/style.css'
    );

    wp_enqueue_style(
        'child-style',
        get_stylesheet_uri(),
        array('parent-style'),
        wp_get_theme()->get('Version')
    );
}

add_action('wp_enqueue_scripts', 'bookstore_child_enqueue_styles');


/* =========================
   WooCommerce support
========================= */

function bookstore_theme_setup() {

    add_theme_support('woocommerce');

    add_theme_support('wc-product-gallery-zoom');

    add_theme_support('wc-product-gallery-lightbox');

    add_theme_support('wc-product-gallery-slider');
}

add_action('after_setup_theme', 'bookstore_theme_setup');


/* =========================
   Remove sidebar shop
========================= */

function bookstore_remove_sidebar() {
    remove_action('woocommerce_sidebar', 'woocommerce_get_sidebar', 10);
}

add_action('init', 'bookstore_remove_sidebar');


/* =========================
   Products per page
========================= */

function bookstore_products_per_page() {
    return 12;
}

add_filter('loop_shop_per_page', 'bookstore_products_per_page', 20);
